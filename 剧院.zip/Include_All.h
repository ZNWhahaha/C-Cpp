//
//  Include_All.h
//  剧场票务管理系统
//
//  Created by 杨帆 on 16/5/30.
//  Copyright © 2016年 杨帆. All rights reserved.
//

#ifndef Include_All_h
#define Include_All_h
#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include"User_Information.h"
#include"Back_In_Ad.h"
#include"Save_User_Information.h"
#include"Open_File_User.h"
#include"Administrator_Registe.h"
#include"Del_Administrator.h"
#include"Look_Administrator.h"
#include"Mod_Administrator.h"
#include"Add_Administrator.h"
#include"Administrator_Menu.h"
#include"Administrator_Login.h"
#include"Menu.h"

#endif /* Include_All_h */
