//
//  main.c
//  剧场票务管理系统
//
//  Created by 杨帆 on 16/5/30.
//  Copyright © 2016年 杨帆. All rights reserved.
//

#include "Include_All.h"

int main(int argc, char const *argv[])
{
    Menu();
    return 0;
}